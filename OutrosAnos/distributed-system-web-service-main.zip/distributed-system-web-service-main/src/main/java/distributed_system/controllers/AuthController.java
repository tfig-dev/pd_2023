package distributed_system.controllers;

import java.sql.SQLException;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import distributed_system.models.RegisterConfig;
import distributed_system.models.User;
import distributed_system.security.TokenService;
import distributed_system.service.repository.DatabaseManager;

@RestController
public class AuthController
{
    private final TokenService tokenService;

    public AuthController(TokenService tokenService)
    {
        this.tokenService = tokenService;
    }

    @PostMapping("/login")
    public String login(Authentication authentication)
    {
        return tokenService.generateToken(authentication);
    }

    @PutMapping("/register")
	public ResponseEntity<String> register(@RequestBody RegisterConfig registerConfig)
	{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if(auth.getAuthorities().size() == 0)
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User is not an admin");

		if(registerConfig == null)
			return ResponseEntity.badRequest().body(null);
		try {
			return(switch(DatabaseManager.getInstance().register(registerConfig.getUsername(),
			 		registerConfig.getName(), registerConfig.getPassword())) {
				case NAME_ALREADY_USED ->  ResponseEntity.status(HttpStatus.CONFLICT).body("Name already used");
				case NAME_BLANK->  ResponseEntity.status(HttpStatus.LENGTH_REQUIRED).body("Name is blank");
				case PASSWORD_BLANK->  ResponseEntity.status(HttpStatus.LENGTH_REQUIRED).body("Password is blank");
				case SUCCESS->  ResponseEntity.status(HttpStatus.OK).body("Success");
				case USERNAME_ALREADY_USED->  ResponseEntity.status(HttpStatus.CONFLICT).body("Username already used");
				case USERNAME_BLANK->  ResponseEntity.status(HttpStatus.LENGTH_REQUIRED).body("Username is blank");
				default ->  ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Something went wrong");
			 }
			);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ResponseEntity.badRequest().body("Something went wrong");
	}

	@DeleteMapping("/delete/{username}")
	public ResponseEntity<String> delete(@PathVariable("username") String username)
	{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if(auth.getAuthorities().size() == 0)
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User is not an admin");

		if(username == null)
			return ResponseEntity.badRequest().body("username cannot be null");
		try {
			return (switch(DatabaseManager.getInstance().deleteUser(username)) {
				case AUTHENTICATED -> ResponseEntity.status(HttpStatus.CONFLICT).body("User is authenticated");
				case DOES_NOT_EXIST -> ResponseEntity.status(HttpStatus.BAD_REQUEST).body("User does not exist");
				case HAS_RESERVATIONS -> ResponseEntity.status(HttpStatus.CONFLICT).body("User has reservations");
				case SUCCESS -> ResponseEntity.status(HttpStatus.OK).body("User has been deleted");
				default -> ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Something went wrong");
			}
		);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ResponseEntity.badRequest().body("Something went wrong");
	}

	@GetMapping("/users")
	public ResponseEntity<List<User>> list()
	{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if(auth.getAuthorities().size() == 0)
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
		
		try {
			List<User> users = DatabaseManager.getInstance().getRegisteredUsers();
			return ResponseEntity.ok(users);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ResponseEntity.badRequest().body(null);
	}
}
