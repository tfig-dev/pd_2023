package distributed_system.controllers;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import distributed_system.models.Spectacle;
import distributed_system.service.repository.DatabaseManager;


@RestController
@RequestMapping("spectacles")
public class SpectaclesController {

  @GetMapping("all")
  public ResponseEntity<Spectacle> getAllSpectacles(){
    return ResponseEntity.ok(null);
  }

  @GetMapping("/")
  public ResponseEntity<List<Spectacle>> getFilteredSpectacles(
  @RequestParam(name = "start",  required = false)String start,
  @RequestParam(name = "end",  required = false)String end)
  {
    LocalDateTime startDateTime = null;
    LocalDateTime endDateTime = null;
    try {
      start = start.replaceAll("\"", "");
      end = end.replaceAll("\"", "");
      if (start != null) {
        startDateTime = LocalDateTime.parse(start, DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
      }
      if (start != null) {
        endDateTime = LocalDateTime.parse(end, DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
      }
    } catch(Exception ignored) {}

    try {
      List<Spectacle> spectacles = DatabaseManager.getInstance().getSpectacles(startDateTime, endDateTime);
      return ResponseEntity.ok(spectacles);
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return ResponseEntity.badRequest().body(null);
  }
}
