package distributed_system.controllers;

import java.sql.SQLException;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import distributed_system.models.Reservation;
import distributed_system.service.repository.DatabaseManager;


@RestController
@RequestMapping("reservations")
public class ReservationsController {
  
  @GetMapping("/paid")
  public ResponseEntity<List<Reservation>> paidReservations() {
    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    try {
      List<Reservation> reservations = DatabaseManager.getInstance()
      .getPaidReservations(auth.getName());
      return ResponseEntity.ok(reservations);
    
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return ResponseEntity.badRequest().body(null);
  }

  @GetMapping("/unpaid")
  public ResponseEntity<List<Reservation>> unpaidReservations() {
    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    try {
      List<Reservation> reservations = DatabaseManager.getInstance()
      .getUnpaidReservations(auth.getName());
      return ResponseEntity.ok(reservations);
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return ResponseEntity.badRequest().body(null);
  }
}
