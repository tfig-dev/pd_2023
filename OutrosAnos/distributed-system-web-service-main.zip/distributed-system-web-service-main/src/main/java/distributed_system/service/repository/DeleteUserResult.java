package distributed_system.service.repository;

public enum DeleteUserResult {
    DOES_NOT_EXIST,
    AUTHENTICATED,
    HAS_RESERVATIONS,
    SUCCESS
}
