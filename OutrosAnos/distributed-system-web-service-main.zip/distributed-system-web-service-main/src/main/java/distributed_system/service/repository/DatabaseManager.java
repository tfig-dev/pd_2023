package distributed_system.service.repository;



import java.io.File;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


import distributed_system.models.Reservation;
import distributed_system.models.Spectacle;
import distributed_system.models.User;


public class DatabaseManager {
    private static DatabaseManager instance;
    private final Connection connection;

    private DatabaseManager() throws SQLException {
        boolean existedBefore;

        existedBefore = new File("database.db").exists();
        connection = DriverManager.getConnection("jdbc:sqlite:database.db");
        if (!existedBefore) {
            try (Scanner scanner = new Scanner("""
          CREATE TABLE espetaculo (
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            descricao TEXT NOT NULL,
            tipo TEXT NOT NULL,
            data_hora TEXT NOT NULL,
            duracao INTEGER NOT NULL,
            local TEXT NOT NULL,
            localidade TEXT NOT NULL,
            pais TEXT NOT NULL,
            classificacao_etaria TEXT NOT NULL,
            visivel INTEGER NOT NULL DEFAULT (0)
          );
                    
          CREATE TABLE lugar (
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            fila TEXT NOT NULL,
            assento TEXT NOT NULL,
            preco REAL NOT NULL,
            espetaculo_id INTEGER REFERENCES espetaculo (id) NOT NULL
          );
                    
          CREATE TABLE utilizador (
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            username TEXT UNIQUE NOT NULL,
            nome TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            administrador INTEGER NOT NULL DEFAULT (0),
            autenticado INTEGER NOT NULL DEFAULT (0)
          );
                    
          CREATE TABLE reserva (
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            data_hora TEXT NOT NULL,
            pago INTEGER NOT NULL DEFAULT (0),
            id_utilizador INTEGER REFERENCES utilizador (id) NOT NULL,
            id_espetaculo INTEGER REFERENCES espetaculo (id) NOT NULL
          );
                    
          CREATE TABLE reserva_lugar (
            id_reserva INTEGER REFERENCES reserva (id) NOT NULL,
            id_lugar INTEGER REFERENCES lugar (id) NOT NULL,
            PRIMARY KEY (id_reserva, id_lugar)
          );
          """)) {
                scanner.useDelimiter("\n\n");
                while (scanner.hasNext()) {
                    try {
                        try (Statement statement = connection.createStatement()) {
                            statement.execute(scanner.next());
                        }
                    } catch (SQLException e) {
                        close();
                        throw new SQLException("could not create table");
                    }
                }
            }
            try (Statement statement = connection.createStatement()) {
                statement.execute("""
                    INSERT INTO utilizador
                    VALUES (NULL, 'admin', 'admin', 'admin', 1, 0);
            """);
            }
        }
    }
    public synchronized static DatabaseManager getInstance()
            throws SQLException {
        if (instance == null)
            instance = new DatabaseManager();
        return instance;
    }
    public synchronized User login(String username, String password) {
        ResultSet resultSet;

        if (username.isBlank() || password.isBlank())
            return null;
        try (Statement statement = connection.createStatement()) {
            resultSet = statement.executeQuery(String.format("""
              SELECT *
              FROM utilizador
              WHERE username = '%s'
              AND password = '%s';
              """, username, password));
            if(resultSet.next()) {
                return new User(
                    resultSet.getInt("id"),
                    resultSet.getString("username"),
                    resultSet.getString("nome"),
                    resultSet.getString("password"),
                    resultSet.getInt("administrador"),
                    resultSet.getInt("autenticado"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public synchronized List<Spectacle> getSpectacles(LocalDateTime start, LocalDateTime end) {
        List<Spectacle> spectacles = new ArrayList<>();
        ResultSet resultSet;

        try (Statement statement = connection.createStatement()) {
            if (start == null && end == null) {
                resultSet = statement.executeQuery("""
                    SELECT *
                    FROM espetaculo;
                """);
            } else if (start == null) {
                resultSet = statement.executeQuery(String.format("""
                    SELECT *
                    FROM espetaculo
                    WHERE time(data_hora, '+'++duracao++' minutes') < time('%s');
                """, Spectacle.dateTimeFormatter.format(end)));
            } else if (end == null) {
                resultSet = statement.executeQuery(String.format("""
                    SELECT *
                    FROM espetaculo
                    WHERE time(data_hora) > time('%s');
                """, Spectacle.dateTimeFormatter.format(start)));
            } else {
                resultSet = statement.executeQuery(String.format("""
                    SELECT *
                    FROM espetaculo
                    WHERE time(data_hora) > time('%s')
                    AND time(data_hora, '+'++duracao++' minutes') < time('%s');
                """,
                        Spectacle.dateTimeFormatter.format(start),
                        Spectacle.dateTimeFormatter.format(end)));
            }
            while (resultSet.next()) {
                spectacles.add(
                    new Spectacle(
                        resultSet.getInt("id"),
                        resultSet.getString("descricao"),
                        resultSet.getString("tipo"),
                        resultSet.getString("data_hora"),
                        resultSet.getInt("duracao"),
                        resultSet.getString("local"),
                        resultSet.getString("localidade"),
                        resultSet.getString("pais"),
                        resultSet.getString("classificacao_etaria"),
                        resultSet.getInt("visivel")
                    )
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return spectacles;
    }
    public synchronized List<Reservation> getPaidReservations(String username) {
        List<Reservation> reservations = new ArrayList<>();
        ResultSet resultSet;
        int userId;

        try (Statement statement = connection.createStatement()) {
            resultSet = statement.executeQuery(String.format("""
                    SELECT *
                    FROM utilizador
                    WHERE username = '%s';
                    """, username));
            if (!resultSet.next())
                return null;
            userId = resultSet.getInt("id");
            resultSet = statement.executeQuery(String.format("""
              SELECT *
              FROM reserva
              WHERE id_utilizador = %d
              AND pago = 1;
              """, userId));
            while (resultSet.next()) {
                reservations.add(
                    new Reservation(
                        resultSet.getInt("id"),
                        resultSet.getString("data_hora"),
                        1,
                        userId,
                        resultSet.getInt("id_espetaculo")
                    )
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return reservations;
    }
    public synchronized List<Reservation> getUnpaidReservations(String username) {
        List<Reservation> reservations = new ArrayList<>();
        ResultSet resultSet;
        int userId;

        try (Statement statement = connection.createStatement()) {
            resultSet = statement.executeQuery(String.format("""
                    SELECT *
                    FROM utilizador
                    WHERE username = '%s';
                    """, username));
            if (!resultSet.next())
                return null;
            userId = resultSet.getInt("id");
            resultSet = statement.executeQuery(String.format("""
          SELECT *
          FROM reserva
          WHERE id_utilizador = %d
          AND pago = 0;
          """, userId));
            while (resultSet.next()) {
                reservations.add(
                        new Reservation(
                                resultSet.getInt("id"),
                                resultSet.getString("data_hora"),
                                0,
                                userId,
                                resultSet.getInt("id_espetaculo")
                        )
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return reservations;
    }
    public synchronized List<User> getRegisteredUsers() {
        List<User> users = new ArrayList<>();
        ResultSet resultSet;

        try (Statement statement = connection.createStatement()) {
            resultSet = statement.executeQuery("""
                SELECT *
                FROM utilizador;
            """);
            while(resultSet.next()) {
                users.add(new User(
                    resultSet.getInt("id"),
                    resultSet.getString("username"),
                    resultSet.getString("nome"),
                    resultSet.getString("password"),
                    resultSet.getInt("administrador"),
                    resultSet.getInt("autenticado")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return users;
    }
    public synchronized RegisterResult register(String username, String name,
                                                String password) {
        ResultSet resultSet;

        if (username.isBlank())
            return RegisterResult.USERNAME_BLANK;
        if (name.isBlank())
            return RegisterResult.NAME_BLANK;
        if (password.isBlank())
            return RegisterResult.PASSWORD_BLANK;
        try (Statement statement = connection.createStatement()) {
            resultSet = statement.executeQuery(String.format("""
              SELECT username
              FROM utilizador
              WHERE username = '%s';
            """, username));
            if (resultSet.next())
                return RegisterResult.USERNAME_ALREADY_USED;
            resultSet = statement.executeQuery(String.format("""
              SELECT nome
              FROM utilizador
              WHERE nome = '%s';
            """, name));
            if (resultSet.next())
                return RegisterResult.NAME_ALREADY_USED;
            statement.execute(String.format("""
              INSERT INTO utilizador
              VALUES (NULL, '%s', '%s', '%s', 0, 0);
            """, username, name, password));
            return RegisterResult.SUCCESS;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return RegisterResult.UNEXPECTED_ERROR;
    }
    public synchronized DeleteUserResult deleteUser(String username) {
        ResultSet resultSet;
        int userId;

        if (username == null || username.isBlank())
            return DeleteUserResult.DOES_NOT_EXIST;
        try (Statement statement = connection.createStatement()) {
            resultSet = statement.executeQuery(String.format("""
                SELECT *
                FROM utilizador
                WHERE username = '%s';
            """, username));
            if (!resultSet.next())
                return DeleteUserResult.DOES_NOT_EXIST;
            if (resultSet.getInt("autenticado") != 0)
                return DeleteUserResult.AUTHENTICATED;
            userId = resultSet.getInt("id");
            resultSet = statement.executeQuery(String.format("""
                SELECT *
                FROM reserva
                WHERE id_utilizador = %d
                AND pago = 1;
            """, userId));
            if (resultSet.next())
                return DeleteUserResult.HAS_RESERVATIONS;
            statement.execute(String.format("""
                DELETE FROM reserva
                WHERE id_utilizador = %d;
            """, userId));
            statement.execute(String.format("""
                DELETE FROM utilizador
                WHERE id = %d;
            """, userId));
            return DeleteUserResult.SUCCESS;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    private void close() throws SQLException {
        connection.close();
    }
}
