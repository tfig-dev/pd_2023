package distributed_system.service.repository;

public enum RegisterResult {
    NAME_BLANK,
    PASSWORD_BLANK,
    USERNAME_ALREADY_USED,
    NAME_ALREADY_USED,
    SUCCESS,
    UNEXPECTED_ERROR,
    USERNAME_BLANK
}
