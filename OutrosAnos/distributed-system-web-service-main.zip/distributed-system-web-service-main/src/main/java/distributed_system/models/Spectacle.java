package distributed_system.models;

import java.text.MessageFormat;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Spectacle {
  private static final MessageFormat ageGroupFormatter1;
  private static final MessageFormat ageGroupFormatter2;
  public static final DateTimeFormatter dateTimeFormatter;
  public static final DateTimeFormatter dateFormatter;
  private final int id;
  private final String description;
  private final String type;
  private final LocalDateTime dateTime;
  private final int duration;
  private final String place;
  private final String city;
  private final String country;
  private final String ageGroup;
  private final boolean visible;

  static {
    ageGroupFormatter1 = new MessageFormat("{0, number}");
    ageGroupFormatter2 = new MessageFormat("{0, number} - {1, number}");
    dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
  }
  
  public Spectacle(int id, String description, String type, String dateTime,
                   int duration, String place, String city, String country,
                   String ageGroup, int visible)
      throws IllegalArgumentException, NullPointerException {
    if (description == null)
      throw new NullPointerException("description cannot be null");
    if (description.isBlank())
      throw new IllegalArgumentException("description cannot be blank");
    if (type == null)
      throw new NullPointerException("type cannot be null");
    if (type.isBlank())
      throw new IllegalArgumentException("type cannot be blank");
    if (dateTime == null)
      throw new NullPointerException("date time cannot be null");
    if (dateTime.isBlank())
      throw new IllegalArgumentException("date time cannot be blank");
    try {
      this.dateTime = LocalDateTime.parse(dateTime, dateTimeFormatter);
    } catch (DateTimeParseException e) {
      e.printStackTrace();
      throw new IllegalArgumentException(
          "date time cannot have invalid format");
    }
    if (duration < 0)
      throw new IllegalArgumentException("duration cannot be negative");
    if (duration == 0)
      throw new IllegalArgumentException("duration cannot be zero");
    if (place == null)
      throw new NullPointerException("place cannot be null");
    if (place.isBlank())
      throw new IllegalArgumentException("place cannot be blank");
    if (city == null)
      throw new NullPointerException("city cannot be null");
    if (city.isBlank())
      throw new IllegalArgumentException("city cannot be blank");
    if (country == null)
      throw new NullPointerException("country cannot be null");
    if (country.isBlank())
      throw new IllegalArgumentException("country cannot be blank");
    if (ageGroup == null)
      throw new NullPointerException("age group cannot be null");
    if (ageGroup.isBlank())
      throw new IllegalArgumentException("age group cannot be blank");
    try {
      ageGroupFormatter1.parse(ageGroup);
    } catch (ParseException e1) {
      try {
        ageGroupFormatter2.parse(ageGroup);
      } catch (ParseException e2) {
        throw new IllegalArgumentException(
            "age group cannot have invalid format");
      }
    }
    this.id = id;
    this.description = description;
    this.type = type;
    this.duration = duration;
    this.place = place;
    this.city = city;
    this.country = country;
    this.ageGroup = ageGroup;
    this.visible = visible != 0;
  }
  public boolean isVisible() {
    return visible;
  }
  public int getId() {
    return id;
  }
  public String getDescription() {
    return description;
  }
  public String getType() {
    return type;
  }
  public LocalDateTime getDateTime() {
    return dateTime;
  }
  public int getDuration() {
    return duration;
  }
  public String getPlace() {
    return place;
  }
  public String getCity() {
    return city;
  }
  public String getCountry() {
    return country;
  }
  public String getAgeGroup() {
    return ageGroup;
  }

  @Override
  public String toString() {
    return description;
  }
}
