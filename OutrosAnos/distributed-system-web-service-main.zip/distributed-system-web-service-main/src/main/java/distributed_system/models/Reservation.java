package distributed_system.models;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Reservation {
  private static final DateTimeFormatter dateTimeFormatter;
  private final int id;
  private final LocalDateTime dateTime;
  private final boolean paid;
  private final int userId;
  private final int spectacleId;

  static {
    dateTimeFormatter = Spectacle.dateTimeFormatter;
  }
  
  public Reservation(int id, String dateTime, int paid, int userId,
                     int spectacleId) {
    if (dateTime == null)
      throw new NullPointerException("date time cannot be null");
    if (paid < 0)
      throw new IllegalArgumentException("paid cannot be negative");
    if (userId < 0)
      throw new IllegalArgumentException("user id cannot be negative");
    if (spectacleId < 0)
      throw new IllegalArgumentException("spectacle id cannot be negative");
    this.id = id;
    try {
      this.dateTime = LocalDateTime.parse(dateTime, dateTimeFormatter);
    } catch (DateTimeParseException e) {
      throw new IllegalArgumentException(
          "date time cannot have invalid format");
    }
    this.paid = paid != 0;
    this.userId = userId;
    this.spectacleId = spectacleId;
  }
  private Reservation(int id) {
    this.id = id;
    this.dateTime = null;
    this.userId = -1;
    this.spectacleId = -1;
    this.paid = false;
  }
  public static Reservation getDummy(int reservationId) {
    return new Reservation(reservationId);
  }
  public int getId() {
    return id;
  }
  public LocalDateTime getDateTime() {
    return dateTime;
  }
  public boolean isPaid() {
    return paid;
  }
  public int getUserId() {
    return userId;
  }
  public int getSpectacleId() {
    return spectacleId;
  }

}
