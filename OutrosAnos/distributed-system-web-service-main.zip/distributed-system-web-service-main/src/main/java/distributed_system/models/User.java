package distributed_system.models;



public class User{
  private final int id;
  private final String username;
  private final String name;
  private final String password;
  private final boolean isAdmin;
  private final boolean isAuth;

  
  public User(int id, String username, String name, String password,
              int isAdmin, int isAuth)
      throws IllegalArgumentException, NullPointerException {
    if (username == null)
      throw new NullPointerException("username cannot be null");
    if (username.isBlank())
      throw new IllegalArgumentException("username cannot be blank");
    if (name == null)
      throw new NullPointerException("name cannot be null");
    if (name.isBlank())
      throw new IllegalArgumentException("name cannot be blank");
    if (password == null)
      throw new NullPointerException("password cannot be null");
    if (password.isBlank())
      throw new IllegalArgumentException("password cannot be blank");
    this.id = id;
    this.username = username;
    this.name = name;
    this.password = password;
    this.isAdmin = isAdmin != 0;
    this.isAuth = isAuth != 0;
  }
  public String getUsername() {
    return username;
  }
  public String getName() {
    return name;
  }
  public String getPassword() {
    return password;
  }
  public boolean isAdmin() {
    return isAdmin;
  }
  public boolean isAuth() {
    return isAuth;
  }
  public int getId() {
    return id;
  }
}
