package pt.isec.pd.spring_boot.exemplo3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exemplo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
