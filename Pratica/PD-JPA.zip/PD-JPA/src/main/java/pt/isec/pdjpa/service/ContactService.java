package pt.isec.pdjpa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pt.isec.pdjpa.model.Contact;
import pt.isec.pdjpa.repository.ContactRepository;
import java.util.List;

@Service
public class ContactService
{
    private ContactRepository contactRepository;

    @Autowired
    public ContactService(ContactRepository contactRepository)
    {
        this.contactRepository = contactRepository;
    }

    public Contact createContact(Contact c)
    {
        c.setId(null);
        return contactRepository.save(c);
    }

    public Contact updateContact(Integer id, Contact c)
    {
        Contact curContact = contactRepository.findById(id).get();
        curContact.setName(c.getName());
        curContact.setEmail(c.getEmail());
        curContact.setPhoneNumber(c.getPhoneNumber());
        return contactRepository.save(curContact);
    }

    public Contact deleteContact(Integer id)
    {
        Contact curContact = contactRepository.findById(id).get();
        contactRepository.deleteById(id);
        return curContact;
    }

    public List<Contact> getAllContacts()
    {
        return contactRepository.findAll();
    }

    public List<Contact> getContactsByName(String name)
    {
        return contactRepository.findByNameLike("%" + name + "%");
    }

    public List<Contact> getContactsByEmail(String email)
    {
        return contactRepository.findByEmail(email);
    }

    public List<Contact> getContactsByPhoneNumber(String phoneNumber)
    {
        return contactRepository.findByPhoneNumber(phoneNumber);
    }

    public List<Contact> getAllPortugueseContacts()
    {
        return contactRepository.findPortuguesePhoneNumbers();
    }
}
