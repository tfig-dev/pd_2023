package pt.isec.pdjpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import pt.isec.pdjpa.model.Contact;
import java.util.List;

@Repository
public interface ContactRepository extends JpaRepository<Contact, Integer>
{
    List<Contact> findByNameLike(String name);
    List<Contact> findByEmail(String email);
    List<Contact> findByPhoneNumber(String phoneNumber);
    @Query("SELECT c FROM Contact c WHERE c.phoneNumber LIKE '+351%'")
    List<Contact> findPortuguesePhoneNumbers();
}
