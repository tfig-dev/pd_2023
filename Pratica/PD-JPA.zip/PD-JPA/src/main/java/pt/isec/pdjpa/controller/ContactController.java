package pt.isec.pdjpa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pt.isec.pdjpa.model.Contact;
import pt.isec.pdjpa.service.ContactService;
import java.util.List;

@RestController
@RequestMapping("contact")
public class ContactController
{
    private ContactService contactService;

    @Autowired
    public ContactController(ContactService contactService)
    {
        this.contactService = contactService;
    }

    @PostMapping
    public ResponseEntity<Contact> createContact(@RequestBody Contact c)
    {
        return ResponseEntity.status(HttpStatus.CREATED).body(contactService.createContact(c));
    }

    @PutMapping("{id}")
    public ResponseEntity<Contact> updateContact(@PathVariable("id") Integer id, @RequestBody Contact c)
    {
        return ResponseEntity.ok().body(contactService.updateContact(id, c));
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Contact> deleteContact(@PathVariable("id") Integer id)
    {
        return ResponseEntity.ok().body(contactService.deleteContact(id));
    }

    @GetMapping("all")
    public ResponseEntity<List<Contact>> getAllContacts()
    {
        return ResponseEntity.ok().body(contactService.getAllContacts());
    }

    @GetMapping("{filter}")
    public ResponseEntity<List<Contact>> getFilteredContacts(@PathVariable("filter") String filter,
                                                             @RequestParam("value") String value)
    {
        switch (filter.toLowerCase())
        {
            case "name": return ResponseEntity.ok().body(contactService.getContactsByName(value));
            case "email": return ResponseEntity.ok().body(contactService.getContactsByEmail(value));
            case "phone": return ResponseEntity.ok().body(contactService.getContactsByPhoneNumber(value));
            default: return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("pt")
    public ResponseEntity<List<Contact>> getAllPortugueseContacts()
    {
        return ResponseEntity.ok().body(contactService.getAllPortugueseContacts());
    }
}
