package pt.isec.pd.ex20;

import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

/**
 *
 * @author José
 */
public class PartialPiValueService /*...*/ {
    
    public PartialPiValueService() throws RemoteException {}

    public double getPartialPiValue(long nIntervals, int nWorkers, int myIndex) throws RemoteException {
        long i;
        double dX, xi, myResult;
        
        if(nIntervals < 1 || nWorkers < 1 || myIndex <1 || myIndex > nWorkers){
            return 0.0;
        }
        
        dX = 1.0/nIntervals;
        myResult = 0;
        
        for (i = myIndex-1 ; i < nIntervals; i += nWorkers) {             
                xi = dX*(i + 0.5);
                myResult += (4.0/(1.0 + xi*xi));               
        }
        
        myResult *= dX;
        
        System.out.println("<Calculado valor parcial: " + myResult + ">");
        
        return myResult;
    }
    
    public static void main(String[] args) {
        try{

            if(args.length<1){
                System.out.println("É necessário um argumento na linha de comando: endereco IP da interface de rede local!");
                System.exit(1);
            }
            
            System.setProperty("java.rmi.server.hostname", args[0]);
		   /*
			* Lanca um registry na maquina local e 
			* no porto por omissao Registry.REGISTRY_PORT.
			*/
			try{                
				LocateRegistry.createRegistry(Registry.REGISTRY_PORT);                                                
				System.out.println("Registry lancado!");
			}catch(RemoteException e){
				//Provavelmente ja tinha sido lancado.
			}
            
            /*
             * Cria o servico PartialPiValueService.
             */
            
            //...
            
            /*
             * Regista o servico com o nome "piWorker" para que os masters possam encontra'-lo, ou seja,
             * obter a sua referencia remota.
             */
            
            //...
            
        }catch(RemoteException e){
            System.out.println("Erro remoto - " + e);
            System.exit(1);
        }catch(Exception e){
            System.out.println("Erro - " + e);
            System.exit(1);
        }  
    }
}
